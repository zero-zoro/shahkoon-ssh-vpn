# NetHogs With Json Output

❇️ NetHogs V 0.8.7




````
bash <(curl -Ls https://raw.githubusercontent.com/HamedAp/Nethogs-Json/main/install.sh --ipv4)
````

